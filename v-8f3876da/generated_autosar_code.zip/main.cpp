/**
 * @file   main.cpp
 * @brief  Application entry point — portable C++ with SimRuntime.
 *
 * @details
 *   This file is the top-level launcher for the ProbeApp application.
 *   It was originally based on AUTOSAR Adaptive (ara:: APIs) and has been
 *   ported to use the portable SimRuntime abstraction layer instead.
 *
 *   Responsibilities:
 *     - Create a single SimRuntime instance on the stack.
 *     - Report execution lifecycle state (replaces ara::exec).
 *     - Instantiate the ProbeApp orchestrator with runtime injection.
 *     - Invoke the application entry function.
 *     - Handle all exceptions and report shutdown state.
 *
 *   Assumptions:
 *     - Single-threaded execution.
 *     - Called from a periodic task context (10 ms).
 *     - All inputs are validated by the caller.
 *
 *   AUTOSAR / ISO 26262 Notes:
 *     - No dynamic memory allocation (no malloc/new for runtime objects).
 *     - No recursion.
 *     - All variables explicitly initialised.
 *     - Fixed-width integer types used where applicable.
 *     - No ara:: headers, types, or namespaces.
 *     - No ara::core::Initialize / Deinitialize.
 *     - No business logic — purely a launcher.
 */

/* =========================================================================
 * Standard library includes
 * ========================================================================= */
#include <iostream>   /* std::cerr (emergency fallback only — not used in normal flow) */
#include <stdexcept>  /* std::exception                                                */
#include <cstdint>    /* Fixed-width integer types: uint32_t, etc.                     */
#include <string>     /* std::string — used for exception message concatenation        */

/* =========================================================================
 * Project includes — portable runtime abstraction
 * ========================================================================= */
#include "runtime/SimRuntime.hpp"   /* SimRuntime : public IRuntime — simulation impl  */

/* =========================================================================
 * Orchestrator include
 * ========================================================================= */
#include "ProbeApp/ProbeApp.hpp"    /* probe::ProbeApp — top-level application class   */

/* =========================================================================
 * main()
 *
 * @brief  Application entry point.
 *
 * @details
 *   Creates the portable SimRuntime on the stack, reports the running state,
 *   instantiates the ProbeApp orchestrator, and invokes the application entry
 *   function.  All exceptions are caught and logged before a controlled
 *   shutdown is performed.
 *
 * @return  0  — application completed successfully.
 * @return  1  — application terminated due to an unhandled exception.
 * ========================================================================= */
int main()
{
    /* ------------------------------------------------------------------
     * 1. Create portable runtime simulation.
     *    Replaces: ara::exec, ara::log, ara::com initialisation.
     *    Constructed on the stack — no dynamic allocation.
     *    Default service-discovery delay: 50 ms.
     * ------------------------------------------------------------------ */
    runtime::SimRuntime simRuntime;

    /* ------------------------------------------------------------------
     * 2. Report execution state: Running.
     *    Replaces: ara::exec::ExecutionClient::ReportExecutionState(
     *                  ara::exec::ExecutionState::kRunning)
     * ------------------------------------------------------------------ */
    simRuntime.reportExecutionState("kRunning");

    /* ------------------------------------------------------------------
     * 3. Log application start.
     *    Replaces: ara::log logger.LogInfo()
     * ------------------------------------------------------------------ */
    simRuntime.logInfo("[APP] Application starting...");

    /* ------------------------------------------------------------------
     * 4. Instantiate orchestrator and invoke entry function.
     *
     *    The orchestrator (probe::ProbeApp) owns and manages all
     *    sub-components internally.  SimRuntime is passed by reference
     *    so that every component shares the same runtime context.
     *
     *    static_cast<void> is applied to the return value of ProbeApp()
     *    to explicitly discard it in compliance with AUTOSAR A0-1-2
     *    (non-void return values must not be silently discarded).
     * ------------------------------------------------------------------ */
    try
    {
        /* Instantiate orchestrator — injects runtime by reference */
        probe::ProbeApp app(simRuntime);

        /* Invoke application entry function; discard non-void return */
        static_cast<void>(app.ProbeApp());
    }
    catch (const std::exception& e)
    {
        /* Typed exception — log message and report terminating state */
        simRuntime.logError(
            std::string("[APP] Exception: ") + e.what()
        );
        simRuntime.reportExecutionState("kTerminating");
        return 1;
    }
    catch (...)
    {
        /* Unknown / non-std exception — log generic message */
        simRuntime.logError(
            "[APP] Unknown exception — application terminated."
        );
        simRuntime.reportExecutionState("kTerminating");
        return 1;
    }

    /* ------------------------------------------------------------------
     * 5. Normal shutdown path.
     *    Log shutdown message and report terminating state before exit.
     * ------------------------------------------------------------------ */
    simRuntime.logInfo("[APP] Application shutting down.");
    simRuntime.reportExecutionState("kTerminating");

    return 0;
}